#!/bin/bash
# Step 2: Overwrite src/config/env.ts with the updated schema including CDC/OIDC variables.

set -e

TARGET_FILE="src/config/env.ts"

# Backup existing file if present
if [ -f "$TARGET_FILE" ]; then
  cp "$TARGET_FILE" "${TARGET_FILE}.bak"
fi

# Write the new env.ts content
cat > "$TARGET_FILE" <<'TS'
import { z } from "zod";

// Environment schema for the backend.
// Includes Commerce configuration and CDC/OIDC settings for SAP CDC integration.

const EnvSchema = z.object({
  PORT: z.coerce.number().default(3002),
  NODE_ENV: z.string().default("development"),

  // Commerce/OCC configuration
  COMMERCE_BASE_URL: z.string().url(),
  COMMERCE_BASE_SITE: z.string().min(1),
  COMMERCE_CLIENT_ID: z.string().min(1),
  COMMERCE_CLIENT_SECRET: z.string().min(1),

  // CDC / OIDC configuration
  CDC_BASE: z.string().url(),               // e.g. https://accounts.eu1.gigya.com
  CDC_API_KEY: z.string().min(1),
  CDC_OIDC_CLIENT_ID: z.string().min(1),

  // Frontend base URL and callback path for OIDC
  FRONTEND_BASE_URL: z.string().url().default("https://mtna-lp.dev"),
  OIDC_CALLBACK_PATH: z.string().default("/oidc/callback"),

  // CORS and rate limiting
  CORS_ALLOW_ORIGINS: z.string().default("https://mtna-lp.dev,https://www.mtna-lp.dev"),
  RATE_LIMIT_MAX: z.coerce.number().default(300),
  RATE_LIMIT_TIME_WINDOW_MS: z.coerce.number().default(60000)
});

export type AppEnv = z.infer<typeof EnvSchema>;

export function loadEnv(): AppEnv {
  const parsed = EnvSchema.parse(process.env);
  return parsed;
}
TS

echo "Updated $TARGET_FILE with new environment schema."
