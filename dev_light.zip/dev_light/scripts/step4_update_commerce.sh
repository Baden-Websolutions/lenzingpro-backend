#!/bin/bash
# Step 4: Update src/services/commerce.ts to add getCurrentUser and preserve existing functionality.

set -e

TARGET_FILE="src/services/commerce.ts"

# Backup existing file if present
if [ -f "$TARGET_FILE" ]; then
  cp "$TARGET_FILE" "${TARGET_FILE}.bak"
fi

# Overwrite with updated content
cat > "$TARGET_FILE" <<'TS'
import fetch from "node-fetch";
import { AppEnv } from "../config/env.js";

/**
 * CommerceClient encapsulates OAuth client credentials flow and OCC API requests.
 */
export class CommerceClient {
  private env: AppEnv;
  private token: string | null = null;
  private tokenExpiresAt: number | null = null;

  constructor(env: AppEnv) {
    this.env = env;
  }

  /**
   * Base URL for OCC calls including version and base site.
   */
  private occBase(): string {
    return `${this.env.COMMERCE_BASE_URL}/occ/v2/${this.env.COMMERCE_BASE_SITE}`;
  }

  /**
   * Fetch a client_credentials token from Commerce. Caches until expiry.
   */
  private async getClientCredentialsToken(): Promise<string> {
    const now = Date.now();
    if (this.token && this.tokenExpiresAt && now < this.tokenExpiresAt) {
      return this.token;
    }
    const url = `${this.env.COMMERCE_BASE_URL}/authorizationserver/oauth/token`;
    const body = new URLSearchParams();
    body.set("grant_type", "client_credentials");
    const basicAuth = Buffer.from(
      `${this.env.COMMERCE_CLIENT_ID}:${this.env.COMMERCE_CLIENT_SECRET}`
    ).toString("base64");
    const resp = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        Authorization: `Basic ${basicAuth}`
      },
      body
    });
    const json = await resp.json();
    if (!resp.ok) {
      throw new Error(json?.error_description || json?.error || `HTTP ${resp.status}`);
    }
    this.token = json.access_token;
    // expires_in is in seconds
    this.tokenExpiresAt = now + (json.expires_in * 1000 - 60000);
    return this.token!;
  }

  /**
   * Get the catalog tree from OCC. Anonymous call using client_credentials token.
   */
  async getCatalogTree(): Promise<any> {
    const accessToken = await this.getClientCredentialsToken();
    const url = `${this.occBase()}/catalogs`;
    const resp = await fetch(url, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${accessToken}`,
        Accept: "application/json"
      }
    });
    const json = await resp.json();
    if (!resp.ok) {
      throw new Error(json?.errors?.[0]?.message || `HTTP ${resp.status}`);
    }
    return json;
  }

  /**
   * Search products within a category using the search endpoint. Accepts optional pagination.
   */
  async searchProductsByCategory(categoryCode: string, page: number = 0, pageSize: number = 10): Promise<any> {
    const accessToken = await this.getClientCredentialsToken();
    const url = new URL(`${this.occBase()}/products/search`);
    url.searchParams.set("query", `:relevance:category:${categoryCode}`);
    url.searchParams.set("pageSize", pageSize.toString());
    url.searchParams.set("currentPage", page.toString());
    const resp = await fetch(url.toString(), {
      method: "GET",
      headers: {
        Authorization: `Bearer ${accessToken}`,
        Accept: "application/json"
      }
    });
    const json = await resp.json();
    if (!resp.ok) {
      throw new Error(json?.errors?.[0]?.message || `HTTP ${resp.status}`);
    }
    return json;
  }

  /**
   * Perform a free text product search.
   */
  async searchProducts(query: string, page: number = 0, pageSize: number = 10): Promise<any> {
    const accessToken = await this.getClientCredentialsToken();
    const url = new URL(`${this.occBase()}/products/search`);
    url.searchParams.set("query", query);
    url.searchParams.set("pageSize", pageSize.toString());
    url.searchParams.set("currentPage", page.toString());
    const resp = await fetch(url.toString(), {
      method: "GET",
      headers: {
        Authorization: `Bearer ${accessToken}`,
        Accept: "application/json"
      }
    });
    const json = await resp.json();
    if (!resp.ok) {
      throw new Error(json?.errors?.[0]?.message || `HTTP ${resp.status}`);
    }
    return json;
  }

  /**
   * Fetch the current logged-in user details using a user-context access token.
   */
  async getCurrentUser(accessToken: string): Promise<any> {
    const url = `${this.occBase()}/users/current`;
    const resp = await fetch(url, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${accessToken}`,
        Accept: "application/json"
      }
    });
    const json = await resp.json();
    if (!resp.ok) {
      throw new Error(json?.errors?.[0]?.message || `HTTP ${resp.status}`);
    }
    return json;
  }
}
TS

echo "Updated $TARGET_FILE with new Commerce client including getCurrentUser()."
