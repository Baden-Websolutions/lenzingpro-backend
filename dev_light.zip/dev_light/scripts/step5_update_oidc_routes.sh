#!/bin/bash
# Step 5: Update src/routes/oidc.ts to implement authorize and callback routes using the OidcService.

set -e

TARGET_FILE="src/routes/oidc.ts"

# Backup existing file
if [ -f "$TARGET_FILE" ]; then
  cp "$TARGET_FILE" "${TARGET_FILE}.bak"
fi

cat > "$TARGET_FILE" <<'TS'
import { FastifyInstance } from "fastify";
import crypto from "crypto";
import { OidcService } from "../services/oidc.js";
import type { AppEnv } from "../config/env.js";

/**
 * Register OIDC routes for initiating the authorization request and handling the callback.
 */
export async function registerOidcRoutes(app: FastifyInstance, env: AppEnv) {
  const oidcService = new OidcService(env);

  // POST /oidc/authorize: generate state/nonce/verifier, store in cookies, return auth URL
  app.post("/oidc/authorize", async (req, reply) => {
    const returnTo = (req.body as any)?.returnTo ?? "/";
    const state = crypto.randomBytes(32).toString("base64url");
    const nonce = crypto.randomBytes(32).toString("base64url");
    const { verifier, challenge } = oidcService.generatePkce();

    // Set transient cookies (HttpOnly, Secure, SameSite=Lax)
    reply.setCookie("oidc_state", state, { httpOnly: true, secure: true, sameSite: "lax", path: "/" });
    reply.setCookie("oidc_nonce", nonce, { httpOnly: true, secure: true, sameSite: "lax", path: "/" });
    reply.setCookie("oidc_verifier", verifier, { httpOnly: true, secure: true, sameSite: "lax", path: "/" });
    reply.setCookie("oidc_return", returnTo, { httpOnly: true, secure: true, sameSite: "lax", path: "/" });

    const authorizationUrl = oidcService.buildAuthorizeUrl(state, nonce, challenge);
    return { authorizationUrl };
  });

  // GET /oidc/callback: handle authorization response, exchange code, validate tokens, create session
  app.get(env.OIDC_CALLBACK_PATH, async (req, reply) => {
    const { code, state, error } = req.query as any;

    // If CDC returned an error, clear cookies and redirect with error
    if (error) {
      reply.clearCookie("oidc_state");
      reply.clearCookie("oidc_nonce");
      reply.clearCookie("oidc_verifier");
      reply.clearCookie("oidc_return");
      return reply.redirect(`${env.FRONTEND_BASE_URL}/login?error=${error}`);
    }

    const storedState = req.cookies.oidc_state;
    const verifier = req.cookies.oidc_verifier;
    const nonce = req.cookies.oidc_nonce;
    const returnTo = req.cookies.oidc_return || "/";

    // Validate state and presence of code/verifier/nonce
    if (!code || !state || state !== storedState || !verifier || !nonce) {
      reply.clearCookie("oidc_state");
      reply.clearCookie("oidc_nonce");
      reply.clearCookie("oidc_verifier");
      reply.clearCookie("oidc_return");
      return reply.redirect(`${env.FRONTEND_BASE_URL}/login?error=state_mismatch`);
    }

    try {
      const tokens = await oidcService.exchangeCode(String(code), String(verifier));
      // Validate ID token if provided
      if (tokens.id_token) {
        await oidcService.verifyIdToken(tokens.id_token, nonce);
      }

      // Set session cookies (HttpOnly, Secure)
      reply.setCookie("session_access", tokens.access_token, {
        httpOnly: true,
        secure: true,
        sameSite: "lax",
        path: "/"
      });
      if (tokens.refresh_token) {
        reply.setCookie("session_refresh", tokens.refresh_token, {
          httpOnly: true,
          secure: true,
          sameSite: "lax",
          path: "/"
        });
      }

      // Clear transient cookies
      reply.clearCookie("oidc_state");
      reply.clearCookie("oidc_nonce");
      reply.clearCookie("oidc_verifier");
      reply.clearCookie("oidc_return");

      // Redirect to original destination
      return reply.redirect(`${env.FRONTEND_BASE_URL}${returnTo}`);
    } catch (err: any) {
      reply.clearCookie("oidc_state");
      reply.clearCookie("oidc_nonce");
      reply.clearCookie("oidc_verifier");
      reply.clearCookie("oidc_return");
      return reply.redirect(`${env.FRONTEND_BASE_URL}/login?error=${encodeURIComponent(err?.message || "auth_failed")}`);
    }
  });
}
TS

echo "Updated $TARGET_FILE with OIDC authorize and callback routes."
