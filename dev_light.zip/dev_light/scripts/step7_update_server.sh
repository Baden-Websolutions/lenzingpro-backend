#!/bin/bash
# Step 7: Update src/server.ts to register cookie plugin, OIDC routes, and session routes with dependencies.

set -e

TARGET_FILE="src/server.ts"

# Backup existing file
if [ -f "$TARGET_FILE" ]; then
  cp "$TARGET_FILE" "${TARGET_FILE}.bak"
fi

cat > "$TARGET_FILE" <<'TS'
import Fastify from "fastify";
import cookie from "@fastify/cookie";
import cors from "@fastify/cors";
import helmet from "@fastify/helmet";
import rateLimit from "@fastify/rate-limit";
import { loadEnv } from "./config/env.js";
import { CommerceClient } from "./services/commerce.js";
import { registerCatalogRoutes } from "./routes/catalog.js";
import { registerSessionRoutes } from "./routes/session.js";
import { registerOidcRoutes } from "./routes/oidc.js";

export async function buildServer() {
  const env = loadEnv();
  const app = Fastify({
    logger: {
      level: env.NODE_ENV === "production" ? "info" : "debug",
      transport: env.NODE_ENV === "production" ? undefined : { target: "pino-pretty" }
    }
  });

  // Register cookie support
  await app.register(cookie);

  // Security, rate limiting and CORS
  await app.register(helmet, { global: true });
  await app.register(rateLimit, {
    max: env.RATE_LIMIT_MAX,
    timeWindow: env.RATE_LIMIT_TIME_WINDOW_MS
  });

  const allowed = env.CORS_ALLOW_ORIGINS.split(",").map(s => s.trim()).filter(Boolean);
  await app.register(cors, {
    origin: (origin, cb) => {
      if (!origin) return cb(null, true);
      if (allowed.includes(origin)) return cb(null, true);
      return cb(new Error("Not allowed by CORS"), false);
    },
    credentials: true
  });

  // Health route
  app.get("/health", async () => ({ ok: true }));

  // Instantiate CommerceClient for OCC access
  const commerce = new CommerceClient(env);

  // Register routes
  await registerCatalogRoutes(app, commerce);
  await registerSessionRoutes(app, commerce);
  await registerOidcRoutes(app, env);

  return { app, env };
}
TS

echo "Updated $TARGET_FILE with cookie plugin and route registration."
