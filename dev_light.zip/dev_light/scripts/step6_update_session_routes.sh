#!/bin/bash
# Step 6: Update src/routes/session.ts to implement authenticated user fetch and logout.

set -e

TARGET_FILE="src/routes/session.ts"

# Backup existing file
if [ -f "$TARGET_FILE" ]; then
  cp "$TARGET_FILE" "${TARGET_FILE}.bak"
fi

cat > "$TARGET_FILE" <<'TS'
import { FastifyInstance } from "fastify";
import type { CommerceClient } from "../services/commerce.js";

/**
 * Register session routes for retrieving the current user and logging out.
 */
export async function registerSessionRoutes(app: FastifyInstance, commerce?: CommerceClient) {
  // GET /session: return user info if authenticated
  app.get("/session", async (req, reply) => {
    const accessToken = req.cookies.session_access;
    if (!accessToken) {
      reply.header("Cache-Control", "no-store");
      return { authenticated: false };
    }
    try {
      const user = await commerce!.getCurrentUser(String(accessToken));
      reply.header("Cache-Control", "no-store");
      return { authenticated: true, user };
    } catch (err: any) {
      reply.clearCookie("session_access");
      reply.clearCookie("session_refresh");
      reply.header("Cache-Control", "no-store");
      return { authenticated: false };
    }
  });

  // POST /session/logout: clear session cookies
  app.post("/session/logout", async (_req, reply) => {
    reply.clearCookie("session_access");
    reply.clearCookie("session_refresh");
    reply.header("Cache-Control", "no-store");
    return { ok: true };
  });
}
TS

echo "Updated $TARGET_FILE with session management routes."
