#!/bin/bash
# Step 1: Install additional dependencies required for OIDC and Cookie handling
# This script installs @fastify/cookie and jose using npm.

# Ensure we are in the repository root where package.json is located
if [ ! -f package.json ]; then
  echo "Error: package.json not found. Run this script from the project root."
  exit 1
fi

# Install the necessary packages as production dependencies
npm install @fastify/cookie jose
