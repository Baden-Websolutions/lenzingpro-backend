# Dev Light Branch Instructions

This directory contains the updated source files and shell scripts for migrating the existing
backend to support SAP CDC OIDC with PKCE, session handling, and improved Commerce
functionality. These changes are intended for a new branch named `dev_light`.

## Structure

- `src/config/env.ts` – Updated environment schema including CDC/OIDC settings.
- `src/services/oidc.ts` – New service for PKCE generation, authorization URL building,
  token exchange, and ID token verification.
- `src/services/commerce.ts` – Extended commerce client with `getCurrentUser()` for
  user‑context API calls while preserving catalog and search methods.
- `src/routes/oidc.ts` – OIDC routes implementing `/oidc/authorize` and the callback
  handler for token exchange and session cookie management.
- `src/routes/session.ts` – Session routes providing `/session` and `/session/logout` to
  query the current user or log out.
- `src/server.ts` – Server bootstrap updated to register cookie plugin, CORS, rate
  limiting, and the new routes.
- `scripts/step*_*.sh` – Executable scripts to apply each change incrementally.

## Applying Changes

1. **Clone your repository** and checkout a new branch called `dev_light`:
   ```bash
   git checkout -b dev_light
   ```
2. **Copy** the files from this directory into the root of your project. Overwrite the
   existing files in `src/` and add the new `src/services/oidc.ts`.
3. **Run the scripts** in order within the project root:
   ```bash
   bash scripts/step1_install_dependencies.sh
   bash scripts/step2_update_env.sh
   bash scripts/step3_create_oidc_service.sh
   bash scripts/step4_update_commerce.sh
   bash scripts/step5_update_oidc_routes.sh
   bash scripts/step6_update_session_routes.sh
   bash scripts/step7_update_server.sh
   ```
   Each script makes one set of changes and backs up existing files with a `.bak` extension.
4. **Commit** the changes to your branch and push to GitHub:
   ```bash
   git add .
   git commit -m "feat: add OIDC PKCE flow, session handling and commerce updates"
   git push origin dev_light
   ```
5. Update your `.env` file with the new CDC/OIDC variables (see `src/config/env.ts`).

## Notes

- These changes are designed for a Fastify backend that lives at `https://api.mtna-lp.dev`.
- Ensure that the CDC OIDC client is configured with the correct redirect URI
  (`https://api.mtna-lp.dev/oidc/callback`).
- After applying changes and installing dependencies, restart your development
  server to test the new endpoints.
